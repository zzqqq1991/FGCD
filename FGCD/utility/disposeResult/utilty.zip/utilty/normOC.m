load OCAll_3
OC = OCAll;
OC = OC * 10;
imshow(OC);
imwrite(OC,'OCAll_3.bmp');